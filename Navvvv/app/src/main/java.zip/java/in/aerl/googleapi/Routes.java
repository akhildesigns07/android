package in.aerl.googleapi;

/**
 * Created by npradeesh on 2/19/2016.
 */
public class Routes {
    public String path;
    public String distance;

    public Routes(String path, String distance) {
        this.path = path;
        this.distance = distance;
    }
}